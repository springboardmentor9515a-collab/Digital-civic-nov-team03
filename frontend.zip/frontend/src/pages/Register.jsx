import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import AuthCard from '../components/AuthCard'
import axios from 'axios'

export default function Register(){
  const [form, setForm] = useState({ name:'', email:'', password:'', location:'India', role:'citizen' })
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(false)

  function update(field, value){
    setForm(prev => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError(null)
    if (!form.name || !form.email || !form.password) { setError('Please fill name, email and password'); return }
    setLoading(true)
    try {
      const base = import.meta.env.VITE_API_URL || 'http://localhost:5000'
      await axios.post(`${base}/api/auth/register`, form)
      alert('Account created. Please sign in.')
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed (or backend not running)')
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthCard activeTab="register">
      <form onSubmit={handleSubmit} className="form">
        <label>Full Name</label>
        <input value={form.name} onChange={e => update('name', e.target.value)} placeholder="Jane Doe" />
        <label>Email</label>
        <input value={form.email} onChange={e => update('email', e.target.value)} placeholder="your@email.com" />
        <label>Password</label>
        <input type="password" value={form.password} onChange={e => update('password', e.target.value)} placeholder="password" />
        <label>Location</label>
        <input value={form.location} onChange={e => update('location', e.target.value)} />
        <label>I am registering as</label>
        <div className="radios">
          <label><input type="radio" name="role" checked={form.role==='citizen'} onChange={() => update('role','citizen')} /> Citizen</label>
          <label><input type="radio" name="role" checked={form.role==='official'} onChange={() => update('role','official')} /> Public Official</label>
        </div>

        {error && <div className="error">{error}</div>}
        <button className="btn" type="submit" disabled={loading}>{loading ? 'Creating...' : 'Create Account'}</button>
        <div className="footer-link">Already have an account? <Link to="/">Sign in</Link></div>
      </form>
    </AuthCard>
  )
}
