import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import AuthCard from '../components/AuthCard'
import axios from 'axios'

export default function Login(){
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError(null)
    if (!email || !password) { setError('Please enter email and password'); return }
    setLoading(true)
    try {
      const base = import.meta.env.VITE_API_URL || 'http://localhost:5000'
      const res = await axios.post(`${base}/api/auth/login`, { email, password })
      localStorage.setItem('token', res.data.token || 'demo-token')
      navigate('/dashboard', { replace: true })
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed (or backend not running)')
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthCard activeTab="login">
      <form onSubmit={handleSubmit} className="form">
        <label>Email</label>
        <input value={email} onChange={e => setEmail(e.target.value)} placeholder="your@email.com" />
        <label>Password</label>
        <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="password" />
        {error && <div className="error">{error}</div>}
        <button className="btn" type="submit" disabled={loading}>{loading ? 'Signing in...' : 'Sign in'}</button>
        <div className="footer-link">Don't have an account? <Link to="/register">Register now</Link></div>
      </form>
    </AuthCard>
  )
}
